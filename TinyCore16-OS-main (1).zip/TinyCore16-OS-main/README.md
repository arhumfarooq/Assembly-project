To run OS:

type in cmd:

qemu-system-x86_64 -drive file=myos.img,format=raw

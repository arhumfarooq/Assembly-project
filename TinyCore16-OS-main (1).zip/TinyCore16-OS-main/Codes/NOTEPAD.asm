.model tiny
.code
start:
    	cli
    	mov ax, 07B0h
    	mov ss, ax
    	mov sp, 00FFh
	sti
	mov ax, cs
    	mov ds, ax

	call clearScreen

	mov si, offset appTitle
	call print_prompt
	call print_newline
	mov si, offset msg1
	call print_prompt
        mov si, offset buffer
	mov cx, 0
	call read_buffer

	WriteText:               ; text writing loop 
    		mov ah, 00h
    		int 16h
    		cmp al, 08h
    		je Backspace

		cmp cx, 1023
		je buffer_full_forwarder

    		cmp al, 13
    		je EnterKey
    		cmp al, 1Bh
    		je Exit

		mov ah, 0Eh    ; for echoing
		int 10h

    		mov [si], al
    		inc si
    		inc cx
    		cmp cx, 1023
		je buffer_full_forwarder
    		jmp WriteText

; FUNCTIONS

buffer_full_forwarder:
	call buffer_full

Backspace:
    cmp cx, 0
    je WriteText

    dec si
    mov byte ptr [si], 0
    dec cx
    
    push cx
    mov ah, 03h     ; Get current cursor position
    mov bh, 0
    int 10h         ; cursor position now in dl for column, dh for row
    pop cx

    cmp dl, 0
    jne normal_backspace

    ; If DL == 0, move to previous line
    cmp dh, 0
    je WriteText        ; already at top left

    dec dh              ; move to previous row
    mov dl, 79          ; move to last column of previous row

    mov ah, 02h         ; set cursor position
    mov bh, 0
    int 10h
	
    push cx
    mov ah, 0Ah
    mov al, ' '  
    mov cx, 1
    mov bh, 0      
    int 10h
    pop cx

    jmp WriteText

; -------- Exit Program --------
Exit:
	mov byte ptr [si], 0     ; adding null value at the end of buffer var
	call write_buffer
	call clearScreen
	mov ax, 0500h
	mov bx, 0000h
	mov es, ax
	push es
	push bx
	retf

EnterKey:
	push cx
	mov ah, 03h
	mov bh, 0
	int 10h
	pop cx
	
	mov bl, 80
	sub bl, dl
	fill_row:
		cmp cx, 1023
		je buffer_full_forwarder
		mov al, ' '
		mov ah, 0Eh
		int 10h
		mov [si], al
		inc si
		inc cx
		dec bl
		cmp bl, 0
		je fill_row_done
		jmp fill_row

normal_backspace:
    	mov ah, 0Eh
    	mov al, 08h        ; move cursor back
    	int 10h
    	mov al, ' '
    	int 10h
    	mov al, 08h        ; move cursor back again
    	int 10h

    	jmp WriteText

buffer_full:
	push cx
	mov ah, 03h
	mov bh, 0
	int 10h
	
	mov cl, dl
	mov ch, dh
	
	mov dh, 24
	mov dl, 0
	mov ah, 02h
	mov bh, 0
	int 10h

	push si
	mov si, offset buffer_full_msg
	call print_prompt
	wait_key:
		mov ah, 00h    ; waiting for key press
		int 16h
		cmp al, 13
		je forward
		jmp wait_key
	
	forward:
		mov dl, 37
		remove_written_prompt:
			mov ah, 0Eh
			mov al, ' '
			int 10h
			mov al, 08h
			int 10h
			mov al, 08h
			int 10h
			dec dl
			cmp dl, 0
			je buffer_full_done
			jmp remove_written_prompt

buffer_full_done:
	mov dh, ch
	mov dl, cl
	mov ah, 02h
	mov bh, 0
	int 10h

	pop si
	pop cx
	jmp WriteText

read_buffer:
	mov ah, 02h
	mov ch, 0
	mov dh, 0
	mov dl, 80h
	mov cl, 62
	mov al, 2
	mov bx, offset buffer
	int 13h
	jc read_buffer_error
	call print_buffer
	ret

fill_row_done:
	inc dh
	mov dl, 0
	mov bh, 0
	mov ah, 02h
	int 10h
    	jmp WriteText


read_buffer_error:
	mov al, 'E'
	mov ah, 0Eh
	int 10h
	jmp WriteText

print_buffer:
	mov si, offset buffer
	call print_prompt
	mov si, offset buffer
	mov cx, 0
	call set_si_buffer
	ret

print_prompt:
	mov ah, 0Eh
	mov al, [si]
	cmp al, 0
	je pdone
	int 10h
	inc si
	jmp print_prompt
pdone:
	ret

print_newline:
	mov ah, 0Eh
	mov al, 13         ; carriage return
	int 10h
	mov al, 10         ; line feed
	int 10h
	ret

write_buffer:
	mov ah, 03h
	mov ch, 0
	mov dh, 0
	mov al, 2
	mov cl, 62
	mov dl, 80h
	mov bx, offset buffer
	int 13h
	jc write_buffer_error
	ret
write_buffer_error:
	mov al, 'E'
	mov ah, 0Eh
	int 10h
	jmp WriteText

set_si_buffer:
	mov al, [si]
	cmp al, 0
	je set_si_done
	inc si
	inc cx
	jmp set_si_buffer

set_si_done:

	ret

; -------- Clear Screen --------
clearScreen:
    mov ah, 0
    mov al, 3
    int 10h
    ret

; VARIABLES

appTitle db 'NOTEPAD', 0
msg1 db 'Enter Data (Press Esc To Exit): ', 0
buffer db 1024 dup(0)
buffer_full_msg db 'File size limit reached. Press Enter', 0

db 2048-($-start) dup(0)
end start

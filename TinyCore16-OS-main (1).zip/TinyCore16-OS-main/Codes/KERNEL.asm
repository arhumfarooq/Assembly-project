.model tiny
org 0
.code
start:
    	cli
    	mov ax, 07B0h
    	mov ss, ax
    	mov sp, 00FFh
	sti
	mov ax, cs
    	mov ds, ax

	mov si, offset kernelTitle
	call print_prompt

	mainloop:
		call print_newline
		mov si, offset prompt
		call print_prompt
	
		mov si, offset input
		call empty_input
		mov si, offset input
		mov cx, 0
		call user_input

		mov si, offset input
		mov di, offset command1
		call first_command_check

	jmp mainloop

; FUNCTIONS

backspace:
    	cmp cx, 0
    	je user_input
    	dec si
    	mov byte ptr [si], 0
    	dec cx
    
    	mov ah, 0Eh
    	mov al, 08h  ; move cursor back
    	int 10h
    	mov al, ' '
    	int 10h
    	mov al, 08h  ; move cursor back again
    	int 10h

    	jmp user_input

print_newline:
	mov ah, 0Eh
	mov al, 13         ; carriage return
	int 10h
	mov al, 10         ; line feed
	int 10h
	ret

print_prompt:
	mov ah, 0Eh
	mov al, [si]
	cmp al, 0
	je pdone
	int 10h
	inc si
	jmp print_prompt
pdone:
	ret

user_input:
	mov ah, 00h
	int 16h
	cmp al, 13
	je idone
	cmp al, 08h
	je backspace

	mov ah, 0Eh   ; for echoing
	int 10h	

	mov [si], al
	inc si
	inc cx
	jmp user_input
idone:
	mov byte ptr [si], 0
	ret

empty_input:
	mov cx, 20
	clear_string:
		mov byte ptr [si], 0
		inc si

	loop clear_string
	ret

command1_handler:   ; shutdown command
	mov dx, 604h
	mov ax, 2000h
	out dx, ax

command2_handler:     ; notepad command      -    Read four sectors starting from sector 4 to location 0x7E00:0000  
    	mov ax, 7E00h
    	mov es, ax
    	mov ah, 02h
    	mov al, 4       ; sectors to read
    	mov ch, 0       ; cylinder
    	mov cl, 4       ; sector 4th
    	mov dh, 0       ; head
    	mov dl, 80h
    	mov bx, 0
    	int 13h

	push es
	push bx
	retf

command3_handler:    ; calculator command       -     Read one sectors starting from sector 8 to location 0x7E00:0000  
    	mov ax, 7E00h
    	mov es, ax
    	mov ah, 02h
    	mov al, 1       ; sectors to read
    	mov ch, 0       ; cylinder
    	mov cl, 8       ; sector 8th
    	mov dh, 0       ; head
    	mov dl, 80h
    	mov bx, 0
    	int 13h

	push es
	push bx
	retf
command4_handler:    ; clock command      -     Read one sectors starting from sector 9 to location 0x7E00:0000  
    	mov ax, 7E00h
    	mov es, ax
    	mov ah, 02h
    	mov al, 1       ; sectors to read
    	mov ch, 0       ; cylinder
    	mov cl, 9       ; sector 8th
    	mov dh, 0       ; head
    	mov dl, 80h
    	mov bx, 0
    	int 13h

	push es
	push bx
	retf
command5_handler:       ; help command
	call print_newline
	mov si, offset helpmsg
	call print_prompt

default_handler:     ; no command match
	mov ah, 0Eh
	mov al, [si]
	cmp al, 0
	je ddone
	int 10h
	inc si
	jmp default_handler
ddone:
	call print_newline
	ret

first_command_check:
	mov cx, 20
	check1:
	    	mov al, [si]        ; char from input
    		mov bl, [di]        ; char from command1
    		cmp al, bl
    		jne first_not_equal

    		cmp al, 0      
    		je first_equal 

    		inc si
		inc di
	loop check1

first_equal:
	call command1_handler
	ret
first_not_equal:
	mov dl, 0

	mov si, offset input
	mov di, offset command2
	call second_command_check
	ret

second_command_check:
	mov cx, 20
	check2:
	    	mov al, [si]        ; char from input
    		mov bl, [di]        ; char from command1
    		cmp al, bl
    		jne second_not_equal

    		cmp al, 0      
    		je second_equal

    		inc si
		inc di
	loop check2
second_equal:
	call command2_handler
	ret
second_not_equal:
	mov dl, 0

	mov si, offset input
	mov di, offset command3
	call third_command_check
	ret

third_command_check:
	mov cx, 20
	check3:
	    	mov al, [si]        ; char from input
    		mov bl, [di]        ; char from command1
    		cmp al, bl
    		jne third_not_equal

    		cmp al, 0      
    		je third_equal

    		inc si
		inc di
	loop check3
third_equal:
	call command3_handler
	ret
third_not_equal:
	mov dl, 0

	mov si, offset input
	mov di, offset command4
	call forth_command_check
	ret

forth_command_check:
	mov cx, 20
	check4:
	    	mov al, [si]        ; char from input
    		mov bl, [di]        ; char from command1
    		cmp al, bl
    		jne forth_not_equal

    		cmp al, 0      
    		je forth_equal

    		inc si
		inc di
	loop check4
forth_equal:
	call command4_handler
	ret
forth_not_equal:
	mov dl, 0

	mov si, offset input
	mov di, offset command5
	call fifth_command_check
	ret

fifth_command_check:
	mov cx, 20
	check5:
	    	mov al, [si]        ; char from input
    		mov bl, [di]        ; char from command1
    		cmp al, bl
    		jne fifth_not_equal

    		cmp al, 0      
    		je fifth_equal

    		inc si
		inc di
	loop check5
fifth_equal:
	call command5_handler
	ret
fifth_not_equal:
	call print_newline
	mov si, offset invalid_cmd_msg 
	call default_handler
	ret

; VARIABLES

prompt db 'OS> ', 0
input db 20 dup (0)
kernelTitle db 'Operating System', 0
command1 db 'shutdown', 0
command2 db 'notepad', 0
command3 db 'calculator', 0
command4 db 'clock', 0
command5 db 'help', 0
invalid_cmd_msg db 'Invalid command. Type ''help'' to see a list of available commands.', 0
helpmsg db 'Available Commands:',13,10
         db 'shutdown    - to turn off the OS',13,10
         db 'notepad     - to open the notepad app',13,10
         db 'calculator  - to open the calculator app',13,10
         db 'clock       - to display the system clock',13,10
         db 'help        - to show this help message', 0




db 1024-($-start) dup(0)
end start

